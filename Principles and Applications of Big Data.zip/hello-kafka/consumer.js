const { Kafka } = require('kafkajs');

// 初始化 Kafka 客户端
const kafka = new Kafka({
  clientId: 'my-node-app', // 客户端标识（自定义）
  brokers: ['localhost:9092'] // Kafka  broker 地址（多个用数组，如 ['broker1:9092', 'broker2:9092']）
});

// 创建消费者（指定消费者组）
const consumer = kafka.consumer({ groupId: 'user-tracking-group' });

// 消费消息的函数
const consumeMessages = async () => {
  try {
    // 1. 连接消费者到 Kafka
    await consumer.connect();
    console.log('消费者已连接');

    // 2. 订阅主题（可订阅多个）
    await consumer.subscribe({
      topic: 'user-tracking', // 要订阅的主题
      fromBeginning: true // 是否从最早的消息开始消费（首次消费建议设为 true）
    });

    // 3. 开始消费消息
    await consumer.run({
      // 每收到一条消息的处理逻辑
      eachMessage: async ({ topic, partition, message }) => {
        console.log('\n收到消息：');
        console.log('主题：', topic);
        console.log('分区：', partition);
        console.log('key：', message.key?.toString()); // 可选的 key
        console.log('value：', JSON.parse(message.value.toString())); // 消息内容
        console.log('偏移量：', message.offset); // 消息在分区中的偏移量
      },
      // 可选：批量处理消息（替代 eachMessage）
      // eachBatch: async ({ batch }) => {
      //   batch.messages.forEach(message => {
      //     console.log('批量消息：', message.value.toString());
      //   });
      // }
    });
  } catch (error) {
    console.error('消费消息失败：', error);
  }
};

// 执行消费（消费者通常需要长期运行，不需要主动断开）
consumeMessages();