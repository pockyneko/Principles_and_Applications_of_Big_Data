const { Kafka } = require('kafkajs');

// 初始化 Kafka 客户端
const kafka = new Kafka({
  clientId: 'my-node-app', // 客户端标识（自定义）
  brokers: ['localhost:9092'] // Kafka  broker 地址（多个用数组，如 ['broker1:9092', 'broker2:9092']）
});

// 创建生产者
const producer = kafka.producer();

// 发送消息的函数
const produceMessage = async () => {
  try {
    // 1. 连接生产者到 Kafka
    await producer.connect();
    console.log('生产者已连接');

    // 2. 发送消息到指定主题
    const result = await producer.send({
      topic: 'user-tracking', // 主题名（若不存在，Kafka 可自动创建，需配置允许自动创建）
      messages: [
        // 消息格式：key（可选）、value（必须，字符串或 Buffer）
        { key: 'login', value: JSON.stringify({ userId: '123', action: 'login', time: new Date() }) },
        { key: 'purchase', value: JSON.stringify({ userId: '456', action: 'purchase', item: 'book' }) }
      ],
      // 可选：指定分区（不指定则按 key 哈希分配）
      // partition: 0
    });

    console.log('消息发送成功：', result);
  } catch (error) {
    console.error('发送消息失败：', error);
  } finally {
    // 3. 断开连接
    await producer.disconnect();
    console.log('生产者已断开连接');
  }
};

// 执行发送
produceMessage();