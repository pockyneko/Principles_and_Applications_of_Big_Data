const hbase = require('hbase')
const client = hbase({
    host: '172.18.11.4',
    port: 8080
})

// 创建表，列族
client.table('test').create('cf', (err, success) => {
    if (err) {
        console.log('create table failed');
    }
    if (success) {
        console.log('create table success');
    }
})

// 插入数据
client.table('test').row('row1').put('cf:name', 'zhangsan',
    (err, success) => {
        if (err) {
            console.log('create data failed');
        }
        if (success) {
            console.log('create data success');
        }

    }
);

// 查询数据
client.table('test').row('row1').get('cf:name', (err, data) => {
    if (err) {
        console.log('get data failed');
    }
    if (data) {
        console.log('data:', data);
    }
});