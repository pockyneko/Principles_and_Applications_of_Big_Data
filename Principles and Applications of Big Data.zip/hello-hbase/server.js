const express = require('express');
const hbase = require('hbase');
const path = require('path');

const app = express();
const PORT = 8080;

// 添加 JSON 解析中间件
app.use(express.json());

// HBase 客户端配置
const client = hbase({
    host: '172.18.11.4',
    port: 8080
});

// 提供静态文件
app.use(express.static('public'));

// ==================== 书签管理 API ====================

// 添加书签
app.post('/api/bookmark', (req, res) => {
    const { title, url, category } = req.body;

    if (!title || !url) {
        return res.json({ error: true, message: '请提供标题和链接' });
    }

    const timestamp = Date.now();
    const bookmarkId = `bm_${timestamp}`;
    const rowKey = bookmarkId;

    const batch = [];
    batch.push({ column: 'info:title', $: title });
    batch.push({ column: 'info:url', $: url });
    batch.push({ column: 'info:category', $: category || '未分类' });
    batch.push({ column: 'info:createdTime', $: timestamp.toString() });
    batch.push({ column: 'stats:visits', $: '0' });

    client.table('bookmarks').row(rowKey).put(batch, (err, success) => {
        if (err) return res.json({ error: true, message: err.message });
        res.json({ success: true, bookmarkId });
    });
});

// 获取所有书签
app.get('/api/bookmarks', (req, res) => {
    const { category } = req.query;

    client.table('bookmarks').scan({
        maxVersions: 1
    }, (err, rows) => {
        if (err) return res.json({ error: true, message: err.message });

        // HBase REST API 返回扁平化的数据，每一行是一个单元格
        // 需要将它们按 rowKey 分组，重新组装成完整的书签对象
        const bookmarkMap = {};

        rows.forEach(row => {
            const rowKey = row.key;
            const column = row.column;
            const value = row.$;

            // 初始化书签对象
            if (!bookmarkMap[rowKey]) {
                bookmarkMap[rowKey] = {
                    id: rowKey,
                    title: '',
                    url: '',
                    category: '',
                    visits: 0,
                    createdTime: 0
                };
            }

            // 根据列名填充数据
            if (column === 'info:title') {
                bookmarkMap[rowKey].title = value;
            } else if (column === 'info:url') {
                bookmarkMap[rowKey].url = value;
            } else if (column === 'info:category') {
                bookmarkMap[rowKey].category = value;
            } else if (column === 'info:createdTime') {
                bookmarkMap[rowKey].createdTime = parseInt(value);
            } else if (column === 'stats:visits') {
                bookmarkMap[rowKey].visits = parseInt(value);
            }
        });

        // 将 Map 转换为数组
        let bookmarks = Object.values(bookmarkMap);

        // 过滤掉空数据
        bookmarks = bookmarks.filter(bm => bm.title && bm.url);

        // 按分类过滤
        if (category && category !== '全部') {
            bookmarks = bookmarks.filter(bm => bm.category === category);
        }

        // 按创建时间倒序排序
        bookmarks.sort((a, b) => b.createdTime - a.createdTime);

        res.json({ bookmarks });
    });
});

// 编辑书签
app.put('/api/bookmark/:id', (req, res) => {
    const { id } = req.params;
    const { title, url, category } = req.body;

    if (!title || !url) {
        return res.json({ error: true, message: '请提供标题和链接' });
    }

    const batch = [];
    batch.push({ column: 'info:title', $: title });
    batch.push({ column: 'info:url', $: url });
    batch.push({ column: 'info:category', $: category || '未分类' });

    client.table('bookmarks').row(id).put(batch, (err, success) => {
        if (err) return res.json({ error: true, message: err.message });
        res.json({ success: true, message: '书签更新成功' });
    });
});

// 访问书签（增加访问量）
app.post('/api/bookmark/:id/visit', (req, res) => {
    const { id } = req.params;

    client.table('bookmarks').row(id).get('stats:visits', (err, data) => {
        if (err) return res.json({ error: true, message: err.message });

        const currentVisits = data && data[0] ? parseInt(data[0].$) : 0;
        const newVisits = currentVisits + 1;

        client.table('bookmarks').row(id).put('stats:visits', newVisits.toString(), (err, success) => {
            if (err) return res.json({ error: true, message: err.message });
            res.json({ success: true, visits: newVisits });
        });
    });
});

// 删除书签
app.delete('/api/bookmark/:id', (req, res) => {
    const { id } = req.params;

    client.table('bookmarks').row(id).delete((err, success) => {
        if (err) return res.json({ error: true, message: err.message });
        res.json({ success: true, message: '书签已删除' });
    });
});

// 批量删除书签
app.post('/api/bookmarks/batch-delete', (req, res) => {
    const { ids } = req.body;

    if (!ids || ids.length === 0) {
        return res.json({ error: true, message: '请提供要删除的书签ID' });
    }

    let completed = 0;
    let errors = [];

    ids.forEach(id => {
        client.table('bookmarks').row(id).delete((err, success) => {
            completed++;
            if (err) errors.push(id);

            if (completed === ids.length) {
                if (errors.length > 0) {
                    res.json({ error: true, message: `部分删除失败: ${errors.join(', ')}` });
                } else {
                    res.json({ success: true, message: `成功删除 ${ids.length} 个书签` });
                }
            }
        });
    });
});

// 搜索书签
app.get('/api/bookmarks/search', (req, res) => {
    const { keyword } = req.query;

    if (!keyword) {
        return res.json({ bookmarks: [] });
    }

    client.table('bookmarks').scan({
        maxVersions: 1
    }, (err, rows) => {
        if (err) return res.json({ error: true, message: err.message });

        const bookmarks = rows
            .map(row => {
                const cols = row.$.column || {};
                return {
                    id: row.key,
                    title: cols['info:title'] || '',
                    url: cols['info:url'] || '',
                    category: cols['info:category'] || '',
                    visits: parseInt(cols['stats:visits'] || 0),
                    createdTime: parseInt(cols['info:createdTime'] || 0)
                };
            })
            .filter(bm =>
                bm.title.toLowerCase().includes(keyword.toLowerCase()) ||
                bm.url.toLowerCase().includes(keyword.toLowerCase())
            )
            .sort((a, b) => b.createdTime - a.createdTime);

        res.json({ bookmarks });
    });
});

// API：获取所有表
app.get('/api/tables', (req, res) => {
    client.tables((err, tables) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to get tables', message: err.message });
        }
        res.json({ tables: tables.map(t => t.name) });
    });
});

// API：获取表的所有行数据
app.get('/api/table/:tableName/rows', (req, res) => {
    const tableName = req.params.tableName;

    client.table(tableName).scan({}, (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to scan table', message: err.message });
        }

        const formattedRows = rows.map(row => {
            const rowData = {
                rowKey: row.key,
                columns: {}
            };

            if (row.$ && Array.isArray(row.$)) {
                row.$.forEach(cell => {
                    rowData.columns[cell.column] = cell.$;
                });
            }

            return rowData;
        });

        res.json({ rows: formattedRows });
    });
});

// API：获取特定行的数据
app.get('/api/table/:tableName/row/:rowKey', (req, res) => {
    const { tableName, rowKey } = req.params;

    client.table(tableName).row(rowKey).get((err, cells) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to get row', message: err.message });
        }

        const rowData = {
            rowKey: rowKey,
            columns: {}
        };

        if (cells && Array.isArray(cells)) {
            cells.forEach(cell => {
                rowData.columns[cell.column] = cell.$;
            });
        }

        res.json(rowData);
    });
});

// API：创建新表
app.post('/api/table/:tableName/create', (req, res) => {
    const { tableName } = req.params;
    const { columnFamily } = req.body;

    if (!columnFamily) {
        return res.status(400).json({ error: true, message: '请提供列族名称' });
    }

    client.table(tableName).create(columnFamily, (err, success) => {
        if (err) {
            return res.status(500).json({ error: true, message: err.message });
        }
        res.json({ success: true, message: `表 ${tableName} 创建成功` });
    });
});

// API：删除表
app.delete('/api/table/:tableName', (req, res) => {
    const { tableName } = req.params;

    client.table(tableName).delete((err, success) => {
        if (err) {
            return res.status(500).json({ error: true, message: err.message });
        }
        res.json({ success: true, message: `表 ${tableName} 删除成功` });
    });
});

// API：插入数据
app.post('/api/table/:tableName/row', (req, res) => {
    const { tableName } = req.params;
    const { rowKey, columnFamily, column, value } = req.body;

    if (!rowKey || !columnFamily || !column || value === undefined) {
        return res.status(400).json({ error: true, message: '请提供完整的参数：rowKey, columnFamily, column, value' });
    }

    const fullColumn = `${columnFamily}:${column}`;

    client.table(tableName).row(rowKey).put(fullColumn, value, (err, success) => {
        if (err) {
            return res.status(500).json({ error: true, message: err.message });
        }
        res.json({ success: true, message: '数据插入成功' });
    });
});

// API：删除行
app.delete('/api/table/:tableName/row/:rowKey', (req, res) => {
    const { tableName, rowKey } = req.params;

    client.table(tableName).row(rowKey).delete((err, success) => {
        if (err) {
            return res.status(500).json({ error: true, message: err.message });
        }
        res.json({ success: true, message: `行 ${rowKey} 删除成功` });
    });
});

// API：删除特定列
app.delete('/api/table/:tableName/row/:rowKey/column/:column', (req, res) => {
    const { tableName, rowKey, column } = req.params;

    client.table(tableName).row(rowKey).delete(column, (err, success) => {
        if (err) {
            return res.status(500).json({ error: true, message: err.message });
        }
        res.json({ success: true, message: `列 ${column} 删除成功` });
    });
});

app.listen(PORT, () => {
    console.log(`✅ 书签管理系统启动成功！访问 http://localhost:${PORT}`);
});
