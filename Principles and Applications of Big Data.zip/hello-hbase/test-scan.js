const hbase = require('hbase');

const client = hbase({
    host: '172.18.11.4',
    port: 8080
});

console.log('正在扫描bookmarks表...\n');

client.table('bookmarks').scan({
    maxVersions: 1
}, (err, rows) => {
    if (err) {
        console.error('错误:', err.message);
        return;
    }
    
    console.log('返回的行数:', rows.length);
    console.log('\n第一行的原始数据结构:');
    if (rows.length > 0) {
        console.log(JSON.stringify(rows[0], null, 2));
    }
    
    console.log('\n所有行的key:');
    rows.forEach((row, index) => {
        console.log(`[${index}] ${row.key}`);
    });
});

