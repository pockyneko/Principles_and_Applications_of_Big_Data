# Node.js 访问 HBase

https://hbase.js.org/api/table/

## 启动 REST Server
```sh
hbase-daemon.sh start rest -p 8080
```

## 停止 REST Server

```sh
hbase-daemon.sh stop rest
```

## 创建 node 容器

```
docker run -itd `
--name mynode `
--network=mynet `
--ip=172.18.11.5 `
-p 8080:8080 `
-v D:/hello-hbase:/root/hello-hbase `
node bash
```
将本地路径映射到容器路径

D:/hello-dfs 为本地路径

/root/hello-dfs 为容器路径

## 初始化目录

```sh
npm init
```

## 安装 hbase

```sh
npm i hbase
```

### 示例代码

```js
const hbase = require('hbase')
const client = hbase({
    host: '172.18.11.4',
    port: 8080
})

// 创建表，列族
client.table('test').create('cf', (err, success) => {
    if (err) {
        console.log('create table failed');
    }
    if (success) {
        console.log('create table success');
    }
})

// 插入数据
client.table('test').row('row1').put('cf:name', 'zhangsan',
    (err, success) => {
        if (err) {
            console.log('create data failed');
        }
        if (success) {
            console.log('create data success');
        }

    }
);

// 查询数据
client.table('test').row('row1').get('cf:name', (err, data) => {
    if (err) {
        console.log('get data failed');
    }
    if (data) {
        console.log('data:', data);
    }
});
```

## HBase 列族 多个 Version

### 查看 VERSION 数

```
describe 'test'  
```

### 设置 VERSION 数

```
alter 'test',{NAME=>'cf',VERSIONS=>3}  
```

### 设置多个 VERSION 数据

```
put 'test','row1', 'cf:name', 'Mike'
put 'test','row1', 'cf:name', 'Rose'
put 'test','row1', 'cf:name', 'Alain'
```

### 查看 VERSION 数据

```
get 'test', 'row1', 'cf:name'
get 'test', 'row1', {COLUMN=>'cf:name',VERSIONS=>3}  
```



