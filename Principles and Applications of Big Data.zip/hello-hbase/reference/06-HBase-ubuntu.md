# HBase

https://abloz.com/hbase/book.html

## 概述

Hbase是一种NoSQL数据库

Hbase是一种分布式存储的数据库

Hbase 支持海量数据，亿级数据

## 结构

### 逻辑结构

名称	| 描述
-|-
列族	|一个列族包含多个列
列		|一个列包含在列族中
行键	|每一行必须有一个行键

### 存储结构

名称			| 描述
-|-
Name Space	| HBase 包含 hbase 和 default 两个命名空间，hbase 存放内置表，default 存放用户表
Table			| 表
Row			| 每一行数据由 Row Key 和 Column 组成，数据按 Row Key 的字典序排列
Column			| 列由 Column Family （列族）和 Column Qualifier（列限定符）进行限定
Time Stamp	| 用于标识数据的不同版本，
Cell		| Row Key、Column Family、Column Qualifier、Time Stamp 唯一确定的单元，Cell 中数据都是字节码存储

### 架构角色

名称			| 描述
-|-
Region Server	| Region 的管理者
Master			| Region Server 的管理者，负载均衡和故障转移
ZooKeeper		| Master 和 Region Server 的一致性服务
HDFS			| 底层的数据存储服务

### Region Server 架构
名称			| 描述
-|-
Store File		| 保存数据的物理文件，以 HFile 的形式存储在 HDFS 上
Mem Store		| 写缓存，HFile 中的数据需要有序，在 Mem Store 中排好序后，写入 Store File
WAL			| Write Ahead Logfile，为防止缓存中数据丢失，先创建 WAL 文件，然后写入 Mem Store
Block Cache		| 读缓存，查询的数据会缓存在 Block Cache 中


```
Region Server
	WAL
	Region
		Store
			Mem Store
			Store File
```

### Master Server

HMaster 是 Master Server 的实现，负责监控集群中的 Region Server 实例

在集群中，Master Server 运行在 NameNode

### RegionServer

HRegionServer是RegionServer的实现，服务和管理Regions

集群中 RegionServer 运行在 DataNode 

```mermaid
graph TD
R1(RegionServer )	--> ZooKeeper
R2(RegionServer )	--> ZooKeeper
R3(RegionServer )	--> ZooKeeper
MasterServer		-->ZooKeeper
R1--> HDFS
R2--> HDFS
R3--> HDFS
R1--> MasterServer
R2--> MasterServer
R3--> MasterServer

```

```
Region Server
	WAL
	Region
		Store
			Mem Store
			Store File
```


### HFile

HBase  在 HDFS 中存储数据的格式。

### Row Key

Rowkey是用来检索记录的唯一主键

Rowkey可以是任意字符串，最大长度是64KB

在HBase内部，Rowkey保存为字节数组。存储时，会按照Rowkey的字典顺序排序存储。


### Column Faimily

HBase中的列都是归属于某一个列簇。

要访问列，也必须以列簇作为前缀，使用冒号进行连接。

列中的数据是没有类型的，全部都是以字节码形式存储。

### Version

在HBase中，是以一个{row,column,version}这样的数据唯一确定一个存储单元，称为cell。

相同的 row 和 column 有不同的 veriosn

默认情况下，HBase是在数据写入时以时间戳作为默认的版本

### Namespace

在HBase中，不同命名空间的表存储是隔离的。

HBase 默认创建了两个命名空间

一个是hbase，这是系统的命名空间，用来存放HBase的一些内部表。

另一个是default，这个是默认的命名空间。不指定命名空间的表都会创建在这个命名空间下。

## 创建模板容器

PowerShell

```
docker run -itd `
--name myhbase `
--hostname myhbase `
--privileged `
-p 16010:16010 `
myhadoop run.sh
```

### 拷贝 hadoop 包到容器
```
docker cp hbase-2.5.0-bin.tar.gz myhbase:/root
```
### 进入容器
```
docker exec -it myhbase bash
```
### 解压缩
```
cd
tar -xzvf hbase-2.5.0-bin.tar.gz
mv hbase-2.5.0 hbase
rm -f hbase-2.5.0-bin.tar.gz
```
### 修改环境变量

编辑 .bash_aliases
```
vi .bash_aliases
```
添加 
```
# HBase
export HBASE_HOME=/root/hbase
export PATH=$HBASE_HOME/bin:${PATH}
```
生效 .bashrc
```
source .bash_aliases
```

### 设置 JAVA_HOME

hbase/conf/hbase-env.sh

```
export JAVA_HOME=/root/java
```

### JAR 包重复绑定

```
cd ~/hbase/lib/client-facing-thirdparty

mv log4j-slf4j-impl-2.17.2.jar log4j-slf4j-impl-2.17.2.jar-copy

mv log4j-slf4j-impl-2.17.2.jar-copy log4j-slf4j-impl-2.17.2.jar
```

## 本地模式
### 启动 HBase
```
start-hbase.sh
```
查看 jps
```
931 Jps
590 HMaster
```
### 启动 HBase Shell
```
hbase shell
```
### HBase Shell 操作
创建表和列族
```
create 'test', 'cf'
```
查看表信息
```
list 'test'
describe 'test'
```
新建数据
```
put 'test', 'row1', 'cf:a', 'value1'
put 'test', 'row2', 'cf:a', 'value2'
put 'test', 'row3', 'cf:a', 'value3'
```
查看数据
```
scan 'test'
get 'test', 'row1'
```
禁用、启用表
```
disable 'test'
enable 'test'
```
删除表，表只有禁用以后才可以被删除
```
dorp 'test
```
退出 HBase Shell
```
quit
```
### 浏览器确认 HBase 信息
```
http://localhost:16010/
```
### 停止 HBase
```
stop-hbase.sh
```
## 伪集群模式
### 配置 hbase-site.xml
```xml
<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
  <property>
    <name>hbase.cluster.distributed</name>
    <value>true</value>
  </property>
  <property>
    <name>hbase.rootdir</name>
    <value>hdfs://localhost:9000/hbase</value>
  </property>
</configuration>
```

删除 hbase.tmp.dir 和 hbase.unsafe.stream.capability.enforce 配置项目

ServerNotRunningYetException: Server is not running yet

```xml
<property>
    <name>hbase.wal.provider</name>
    <value>filesystem</value>
</property>
```

拷贝配置文件
```
docker cp hbase-site.xml mycentos:/root/hbase/conf/
```
### 启动 Hadoop
格式化 hadoop namenode
```
hdfs namenode -format
```
启动 hadoop
```
start-dfs.sh
```
### 启动 HBase

启动 HBase
```
start-hbase.sh
```
查看 jps
```
5265 HRegionServer
4996 HQuorumPeer
5463 Jps
2008 SecondaryNameNode
5130 HMaster
1772 DataNode
1644 NameNode
```
### Shell 操作
启动 HBase Shell
```
hbase shell
```
创建表和列组
```
create 'test', 'cf'
```
查看表信息
```
list 'test'
```
查看 hadoop 下 /hbase 目录信息
```
hdfs dfs -ls /hbase
```
### 关闭 HBase Hadoop
```
stop-hbase.sh
stop-dfs.sh
```
##  集群模式

### 删除 /tmp 目录

rm -rf /tmp

### 创建 myhbase 镜像

docker commit myhbase myhbase

### 集群信息

Node Name|Master|ZooKeeper|RegionServer
-|-|-|-
mymaster|yes|yes|no
myworker1|backup|yes|yes
myworker2|no|yes|yes
myworker3|no|yes|yes

### 配置信息
hbase-site.xml
```xml
<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
  <property>
    <name>hbase.rootdir</name>
    <value>hdfs://mymaster:9000/hbase</value>
  </property>
  <property>
    <name>hbase.cluster.distributed</name>
    <value>true</value>
  </property>
  <property>
    <name>hbase.zookeeper.quorum</name>
    <value>mymaster,myworker1,myworker2,myworker3</value>
  </property>
</configuration>
```

backup-masters
```
myworker1
```
regionservers
```
myworker1
myworker2
myworker3

```

backup-masters 和 regionservers 文件不能使用 Windows 环境编辑，Windows 环境中换行 0A 0D，需要 Linux 环境，换行 0A 。

### 创建集群
Power Shell
```batch
@echo off
setlocal enabledelayedexpansion
set IP_PREFIX=172.18.11
set /a HOST_COUNT=4
set /a SUB_HOST_COUNT=%HOST_COUNT% - 1

set ADD_HOST=
for /l %%i in (1,1, %SUB_HOST_COUNT%) do (
    set ADD_HOST=!ADD_HOST! --add-host=myworker%%i:%IP_PREFIX%.%%i
)

:: mymaster
docker run -itd ^
--name mymaster ^
--hostname mymaster ^
--network=mynet ^
--ip=172.18.11.%HOST_COUNT%^
%ADD_HOST% ^
--privileged ^
-p 8088:8088 ^
-p 9870:9870 ^
-p 16010:16010 ^
myhbase run.sh

:: myworker
set /a HOST_COUNT=%HOST_COUNT% - 1
set /a SUB_HOST_COUNT=%HOST_COUNT% - 1

for /l %%i in (1,1, %HOST_COUNT%) do (
    set /a K=%HOST_COUNT% + 1
    set ADD_HOST=--add-host=mymaster:%IP_PREFIX%.!K!
    for /l %%j in (1,1, %SUB_HOST_COUNT%) do (
        set /a K=%%i+%%j-1
        set /a K=!k!%%%HOST_COUNT%+1
        set ADD_HOST=!ADD_HOST! --add-host=myworker!k!:%IP_PREFIX%.!k!
    )
    docker run -itd ^
    --network=mynet ^
    --name=myworker%%i ^
    --hostname=myworker%%i ^
    --ip=%IP_PREFIX%.%%i ^
    !ADD_HOST! ^
    --privileged ^
    myhbase run.sh
)
@echo on
```
### 设置配置文件

PowerShell
```batch
@echo off
for %%s in (mymaster myworker1 myworker2 myworker3) DO (
	echo %%s config files copying ...
	docker cp workers %%s:/root/hadoop/etc/hadoop/
	docker cp core-site.xml %%s:/root/hadoop/etc/hadoop/
	docker cp hdfs-site.xml %%s:/root/hadoop/etc/hadoop/
	docker cp mapred-site.xml %%s:/root/hadoop/etc/hadoop/
	docker cp yarn-site.xml %%s:/root/hadoop/etc/hadoop/
	docker cp hbase-site.xml %%s:/root/hbase/conf/
	docker cp backup-masters %%s:/root/hbase/conf/
	docker cp regionservers %%s:/root/hbase/conf/
)
@echo on
```
### 启动集群
进入 mymaster 容器
```
docker exec -it mymaster bash
```
格式化 name node
```
hdfs namenode -format
```
启动 hadoop
```
start-dfs.sh
```
确认 jps

mymaster
```
741 Jps
346 NameNode
606 SecondaryNameNode
```
myworker1
```
134 DataNode
216 Jps
```
myworker2
```
122 DataNode
204 Jps
```
启动 HBase
```
start-hbase.sh
```
确认 jps

mymaster
```
596 SecondaryNameNode
1095 HMaster
983 HQuorumPeer
1422 Jps
335 NameNode
```
myworker1
```
359 HRegionServer
809 Jps
125 DataNode
222 HQuorumPeer
478 HMaster
```
myworker2, myworker3
```
115 DataNode
212 HQuorumPeer
613 Jps
349 HRegionServer
```

## Node.js 访问


## Java 访问
### 修改 hosts
添加
```
127.0.0.1   mycentos
```
### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.flybird.bigdata</groupId>
    <artifactId>hbase</artifactId>
    <version>1.0</version>

    <properties>
        <java.version>1.8</java.version>
        <hbase.version>2.3.0</hbase.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.apache.hbase</groupId>
            <artifactId>hbase-client</artifactId>
            <version>${hbase.version}</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
			    <groupId>org.apache.maven.plugins</groupId>
			    <artifactId>maven-jar-plugin</artifactId>
			    <version>2.4</version>
			    <configuration>
			        <archive>
			            <manifest>
			                <addClasspath>true</addClasspath>
			                <classpathPrefix>lib/</classpathPrefix>
			                <mainClass>com.yulecode.app.App</mainClass>
			            </manifest>
			        </archive>
			    </configuration>
			</plugin>
			<plugin>
			    <groupId>org.apache.maven.plugins</groupId>
			    <artifactId>maven-dependency-plugin</artifactId>
			    <executions>
			        <execution>
			            <id>copy</id>
			            <phase>package</phase>
			            <goals>
			                <goal>copy-dependencies</goal>
			            </goals>
			            <configuration>
			                <outputDirectory>
			                    ${project.build.directory}/lib
			                </outputDirectory>
			            </configuration>
			        </execution>
			    </executions>
			</plugin>
        </plugins>
    </build>
</project>
```

```xml
    <build>
        <plugins>
            <plugin>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <source>${java.version}</source>
                    <target>${java.version}</target>
                </configuration>
            </plugin>
            <plugin>
                <artifactId>maven-assembly-plugin</artifactId>
                <configuration>
                    <descriptorRefs>
                        <descriptorRef>jar-with-dependencies</descriptorRef>
                    </descriptorRefs>
                </configuration>
                <executions>
                    <execution>
                        <id>make-assembly</id>
                        <phase>package</phase>
                        <goals>
                            <goal>single</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>

```

### Application.java
```java
package com.yulecode.app

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

public class App
{
	private static TableName tableName = TableName.valueOf("test");

	public static void main(String[] args) throws IOException {

	    Configuration config = HBaseConfiguration.create();
	    config.set("hbase.zookeeper.quorum", "mymaster, myworker1, myworker2, myworker3");

	    Connection connection = ConnectionFactory.createConnection(config);

	    Table hTable = connection.getTable(tableName);

	    Scan scan = new Scan();

	    scan.addColumn(Bytes.toBytes("cf"), Bytes.toBytes("a"));
	    ResultScanner scanner = hTable.getScanner(scan);
	    for (Result result = scanner.next(); result != null; result = scanner.next()) {
	        System.out.println("Found row : " + result);
	    }

	    scanner.close();
	    hTable.close();
	    connection.close();
    }
}

```

新建工程

```
mvn archetype:generate -DgroupId=com.yulecode.app -DartifactId=my-app  -DinteractiveMode=false
```

打包

```
mvn package
```

运行

```
java -cp target/hbase-1.0-jar-with-dependencies.jar com.yulecode.app.App
java -jar hbase-1.0.jar
```
