const hbase = require('hbase')

const client = hbase({
    host: '172.18.11.4',
    port: 8080
})

// 测试数据
const testBookmarks = [
    // 技术类
    { title: 'GitHub', url: 'https://github.com', category: '技术' },
    { title: 'Stack Overflow', url: 'https://stackoverflow.com', category: '技术' },
    { title: 'MDN Web Docs', url: 'https://developer.mozilla.org', category: '技术' },
    { title: 'Vue.js', url: 'https://vuejs.org', category: '技术' },
    { title: 'React', url: 'https://react.dev', category: '技术' },
    { title: 'Node.js', url: 'https://nodejs.org', category: '技术' },

    // 学习类
    { title: '菜鸟教程', url: 'https://www.runoob.com', category: '学习' },
    { title: 'W3Schools', url: 'https://www.w3schools.com', category: '学习' },
    { title: 'freeCodeCamp', url: 'https://www.freecodecamp.org', category: '学习' },
    { title: 'Coursera', url: 'https://www.coursera.org', category: '学习' },

    // 工作类
    { title: 'Google', url: 'https://www.google.com', category: '工作' },
    { title: '百度', url: 'https://www.baidu.com', category: '工作' },
    { title: 'Gmail', url: 'https://mail.google.com', category: '工作' },
    { title: 'Trello', url: 'https://trello.com', category: '工作' },
    { title: 'Notion', url: 'https://www.notion.so', category: '工作' },

    // 娱乐类
    { title: '哔哩哔哩', url: 'https://www.bilibili.com', category: '娱乐' },
    { title: 'YouTube', url: 'https://www.youtube.com', category: '娱乐' },
    { title: '网易云音乐', url: 'https://music.163.com', category: '娱乐' },
    { title: 'Spotify', url: 'https://www.spotify.com', category: '娱乐' },
    { title: '豆瓣', url: 'https://www.douban.com', category: '娱乐' },

    // 其他类
    { title: '知乎', url: 'https://www.zhihu.com', category: '其他' },
    { title: 'Reddit', url: 'https://www.reddit.com', category: '其他' },
    { title: 'Medium', url: 'https://medium.com', category: '其他' },
]

// 插入测试数据
let completed = 0
let errors = 0

console.log('开始插入测试数据...\n')

testBookmarks.forEach((bookmark, index) => {
    const timestamp = Date.now() + index * 1000 // 每个书签间隔1秒，保证顺序
    const bookmarkId = `bm_${timestamp}`

    const batch = []
    batch.push({ column: 'info:title', $: bookmark.title })
    batch.push({ column: 'info:url', $: bookmark.url })
    batch.push({ column: 'info:category', $: bookmark.category })
    batch.push({ column: 'info:createdTime', $: timestamp.toString() })
    batch.push({ column: 'stats:visits', $: Math.floor(Math.random() * 50).toString() }) // 随机访问量 0-50

    client.table('bookmarks').row(bookmarkId).put(batch, (err, success) => {
        completed++

        if (err) {
            errors++
            console.log(`❌ [${completed}/${testBookmarks.length}] 失败: ${bookmark.title} - ${err.message}`)
        } else {
            console.log(`✅ [${completed}/${testBookmarks.length}] 成功: ${bookmark.title}`)
        }

        // 全部完成
        if (completed === testBookmarks.length) {
            console.log('\n========================================')
            console.log(`插入完成！`)
            console.log(`成功: ${testBookmarks.length - errors} 个`)
            console.log(`失败: ${errors} 个`)
            console.log('========================================\n')

            if (errors === 0) {
                console.log('🎉 所有测试数据插入成功！')
                console.log('现在可以访问 http://localhost:8080 查看书签了！')
            }
        }
    })
})

