#!/bin/bash

# 停止旧服务
pkill -f "node.*server.js" || true

# 等待进程停止
sleep 1

# 启动服务器
cd /root/hello-hbase
nohup node server.js > /tmp/server.log 2>&1 &

# 等待服务器启动
sleep 2

# 运行测试数据插入
node insert-test-data.js

# 等待数据插入完成
sleep 3

# 检查数据
echo "=== 检查书签数量 ==="
curl -s http://localhost:8080/api/bookmarks | grep -c '"id"'

echo ""
echo "=== 检查前5个书签 ==="
curl -s http://localhost:8080/api/bookmarks | head -500

