# HBase Web 数据查看器

## 项目说明
这是一个简单的 Web 界面，用于查看容器 mymaster 中的 HBase 数据。

## 项目结构
```
hello-hbase/
├── index.js          # 原始 HBase 测试代码
├── server.js         # Express Web 服务器（端口 8080）
├── package.json      # 项目配置文件
└── public/
    └── index.html    # 前端界面
```

## 功能特性
- 📊 显示所有 HBase 表列表
- 🔍 查看指定表的所有数据
- 📈 显示表数量和行数统计
- 🎨 美观的现代化界面
- 🔄 实时刷新数据

## 容器配置
```bash
docker run -itd \
  --name mynode \
  --network=mynet \
  --ip=172.18.11.5 \
  -p 8080:8080 \
  -v D:/hello-hbase:/root/hello-hbase \
  node bash
```

## 在容器 mynode 中运行步骤

### 方法一：进入容器后操作（推荐）

```bash
# 1. 进入容器
docker exec -it mynode bash

# 2. 进入项目目录
cd /root/hello-hbase

# 3. 安装依赖（首次运行需要）
npm install

# 4. 启动 Web 服务器
npm start
```

### 方法二：一行命令直接启动

```bash
docker exec -it mynode bash -c "cd /root/hello-hbase && npm install && npm start"
```

### 3. 访问界面
在浏览器中打开：`http://localhost:8080`

## API 接口

服务器提供以下 API 接口：

- `GET /api/tables` - 获取所有表列表
- `GET /api/table/:tableName/rows` - 获取指定表的所有行数据
- `GET /api/table/:tableName/row/:rowKey` - 获取指定行的数据

## 使用说明

1. 打开浏览器访问 `http://localhost:8080`
2. 在下拉菜单中选择要查看的表（如：test）
3. 点击"加载数据"按钮
4. 数据会以表格形式显示在页面上
5. 可以点击"刷新表列表"获取最新的表信息

## 注意事项

- 确保 HBase 服务在 172.18.11.4:8080 上可访问
- 确保容器 mynode 和 mymaster 在同一网络 mynet 中
- 服务器端口是 8080（与容器端口映射一致）
- 项目挂载路径：`D:/hello-hbase` → `/root/hello-hbase`
