#!/bin/bash
cd /root/hello-hbase
pkill -9 node
sleep 2
nohup node server.js > /tmp/server.log 2>&1 &
sleep 2
echo "Server started"
ps aux | grep node | grep -v grep

