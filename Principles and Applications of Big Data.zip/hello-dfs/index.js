const express = require("express");
require('dotenv').config();
const bodyParser = require('body-parser');
const axios = require('axios');
const multer = require('multer');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.text()); // 用于接收文件内容
app.use(bodyParser.urlencoded({ extended: true }));

// 配置 multer 用于文件上传
const upload = multer({ storage: multer.memoryStorage() });

const PORT = process.env.PORT || 8000;

// HDFS 配置 - 从环境变量或默认值获取
const HDFS_NAMENODE_HOST = process.env.HDFS_NAMENODE_HOST || 'localhost';
const HDFS_NAMENODE_PORT = process.env.HDFS_NAMENODE_PORT || 50070;
const HDFS_USER = process.env.HDFS_USER || 'hadoop';

const baseHdfsUrl = `http://${HDFS_NAMENODE_HOST}:${HDFS_NAMENODE_PORT}/webhdfs/v1/user/root`;

// 添加静态文件服务
app.use(express.static('public'));

// 添加根路径重定向到前端页面
app.get('/', (req, res) => {
  res.redirect('/index.html');
});

/**
 * 创建 HDFS 文件夹
 * POST /api/hdfs/mkdir
 * 请求体: { "path": "/user/test/newdir" }
 */
app.post('/api/hdfs/mkdir', async (req, res) => {
  try {
    const { path } = req.body;

    if (!path) {
      return res.status(400).json({ error: '请提供 HDFS 路径' });
    }

    const url = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=MKDIRS`;

    const response = await axios.put(url);

    res.status(200).json({
      message: `文件夹创建成功: ${path}`,
      success: response.data.boolean
    });
  } catch (error) {
    console.error('创建文件夹错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '创建文件夹失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 创建 HDFS 文件
 * POST /api/hdfs/create
 * 请求体: 文件内容 (文本)
 * 查询参数: path (例如: /user/test/file.txt)
 */
app.post('/api/hdfs/create', async (req, res) => {
  try {
    const { path } = req.query;
    const fileContent = req.body;

    if (!path) {
      return res.status(400).json({ error: '请提供 HDFS 文件路径' });
    }

    // 提取父目录路径并确保存在
    const parentPath = path.substring(0, path.lastIndexOf('/'));
    if (parentPath) {
      try {
        const mkdirUrl = `${baseHdfsUrl}${parentPath}?user.name=${HDFS_USER}&op=MKDIRS`;
        await axios.put(mkdirUrl);
        console.log(`父目录已创建或已存在: ${parentPath}`);
      } catch (mkdirError) {
        console.warn('创建父目录失败(可能已存在):', mkdirError.message);
      }
    }

    // 第一步: 获取创建文件的重定向 URL
    const createUrl = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=CREATE&overwrite=true`;

    const createResponse = await axios.put(createUrl, null, {
      maxRedirects: 0,
      validateStatus: status => status === 307
    });

    // 第二步: 使用重定向 URL 写入文件内容
    const writeUrl = createResponse.headers.location;
    await axios.put(writeUrl, fileContent, {
      headers: {
        'Content-Type': 'application/octet-stream'
      }
    });

    res.status(200).json({
      message: `文件创建成功: ${path}`
    });
  } catch (error) {
    console.error('创建文件错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '创建文件失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 上传文件到 HDFS (增强版:自动创建父目录,上传后验证)
 * POST /api/hdfs/upload
 * 表单数据: file (文件), path (目标路径)
 */
app.post('/api/hdfs/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: '请选择要上传的文件' });
    }

    let { path = '' } = req.body;
    const fileName = req.file.originalname;
    const fileContent = req.file.buffer;

    // 规范化路径：去除首尾空格，确保格式正确
    path = (path || '').trim();

    // 如果path为空或只是'/'，文件直接放在根目录
    if (!path || path === '/') {
      path = '';
    } else {
      // 确保路径以 / 开头
      if (!path.startsWith('/')) {
        path = '/' + path;
      }
      // 去除末尾的 /
      path = path.replace(/\/+$/, '');
      // 去除多余的连续斜杠
      path = path.replace(/\/+/g, '/');
    }

    const fullPath = path ? `${path}/${fileName}` : `/${fileName}`;

    // 自动创建父目录（如果不是根目录）
    if (path && path !== '/') {
      try {
        const mkdirUrl = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=MKDIRS`;
        await axios.put(mkdirUrl);
      } catch (mkdirError) {
        // 目录已存在或创建失败，继续后续流程
      }
    }

    // 第一步: 获取创建文件的重定向 URL
    const createUrl = `${baseHdfsUrl}${fullPath}?user.name=${HDFS_USER}&op=CREATE&overwrite=true`;
    let createResponse;
    try {
      createResponse = await axios.put(createUrl, null, {
        maxRedirects: 0,
        validateStatus: status => status === 307
      });
    } catch (err) {
      return res.status(500).json({ error: 'HDFS CREATE 步骤失败', details: err.message });
    }

    // 第二步: 使用重定向 URL 写入文件内容
    const writeUrl = createResponse.headers.location;
    try {
      await axios.put(writeUrl, fileContent, {
        headers: {
          'Content-Type': 'application/octet-stream'
        }
      });
    } catch (err) {
      return res.status(500).json({ error: 'HDFS 写入文件失败', details: err.message });
    }

    // 上传后立即验证文件是否存在
    try {
      const checkUrl = `${baseHdfsUrl}${fullPath}?user.name=${HDFS_USER}&op=GETFILESTATUS`;
      await axios.get(checkUrl);
    } catch (err) {
      return res.status(500).json({ error: '文件上传后未找到', details: err.message });
    }

    res.status(200).json({
      message: `文件上传成功: ${fileName}`,
      path: fullPath
    });
  } catch (error) {
    console.error('上传文件错误:', error);
    res.status(error.response?.status || 500).json({
      error: '上传文件失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 下载文件(支持二进制)
 * GET /api/hdfs/download
 * 查询参数: path (例如: /user/root/image.png)
 */
app.get('/api/hdfs/download', async (req, res) => {
  try {
    const { path } = req.query;

    if (!path) {
      return res.status(400).json({ error: '请提供 HDFS 文件路径' });
    }

    const url = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=OPEN`;

    // 直接转发 HDFS 的响应流
    const response = await axios.get(url, {
      responseType: 'stream'
    });

    // 设置响应头
    const fileName = path.split('/').pop();
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(fileName)}"`);
    res.setHeader('Content-Type', response.headers['content-type'] || 'application/octet-stream');

    // 将 HDFS 响应流传递给客户端
    response.data.pipe(res);
  } catch (error) {
    console.error('下载文件错误:', error.message);

    // ✅ 修复:只返回错误消息,避免序列化 Stream 对象
    res.status(error.response?.status || 500).json({
      error: '下载文件失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 重命名文件或文件夹
 * POST /api/hdfs/rename
 * 请求体: { "oldPath": "/old.txt", "newPath": "/new.txt" }
 */
app.post('/api/hdfs/rename', async (req, res) => {
  try {
    const { oldPath, newPath } = req.body;

    if (!oldPath || !newPath) {
      return res.status(400).json({ error: '请提供旧路径和新路径' });
    }

    const url = `${baseHdfsUrl}${oldPath}?user.name=${HDFS_USER}&op=RENAME&destination=${encodeURIComponent(baseHdfsUrl + newPath)}`;

    const response = await axios.put(url);

    const renameSuccess = response.data?.boolean === true;

    if (renameSuccess) {
      res.status(200).json({
        message: `重命名成功: ${oldPath} -> ${newPath}`,
        success: true
      });
    } else {
      res.status(500).json({
        error: '重命名失败',
        message: 'HDFS 返回 false'
      });
    }
  } catch (error) {
    console.error('重命名错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '重命名失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 删除 HDFS 文件或文件夹
 * DELETE /api/hdfs/delete
 * 查询参数:
 *   path: 要删除的HDFS路径 (例如: /file.txt 或 /folder)
 *   recursive: 是否递归删除(删除文件夹时需要,可选值: true/false,默认false)
 */
app.delete('/api/hdfs/delete', async (req, res) => {
  try {
    const { path, recursive = 'false' } = req.query;

    if (!path) {
      return res.status(400).json({ error: '请提供要删除的 HDFS 路径' });
    }

    const url = new URL(`${baseHdfsUrl}${path}`);
    url.searchParams.append('user.name', HDFS_USER);
    url.searchParams.append('op', 'DELETE');
    url.searchParams.append('recursive', recursive);

    const response = await axios.delete(url.toString());

    // 检查 HDFS 返回的 boolean 值
    const deleteSuccess = response.data?.boolean === true;

    if (deleteSuccess) {
      res.status(200).json({
        message: `删除成功: ${path}`,
        success: true
      });
    } else {
      res.status(500).json({
        error: '删除失败',
        message: 'HDFS 返回 false,可能路径不存在或需要 recursive=true 参数'
      });
    }
  } catch (error) {
    console.error('删除错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '删除失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 读取 HDFS 文件
 * GET /api/hdfs/read
 * 查询参数: path (例如: /user/root/hello.txt)
 */
app.get('/api/hdfs/read', async (req, res) => {
  try {
    const { path } = req.query;

    if (!path) {
      return res.status(400).json({ error: '请提供 HDFS 文件路径' });
    }

    const url = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=OPEN`;

    const response = await axios.get(url);

    res.status(200).json({
      message: `读取成功: ${path}`,
      content: response.data
    });
  } catch (error) {
    console.error('读取文件错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '读取文件失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

/**
 * 列出 HDFS 目录内容
 * GET /api/hdfs/list
 * 查询参数: path (例如: /user/root,默认为根目录)
 */
app.get('/api/hdfs/list', async (req, res) => {
  try {
    const { path = '' } = req.query;

    const url = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=LISTSTATUS`;

    const response = await axios.get(url);

    res.status(200).json({
      message: `列出目录成功: ${path || '/'}`,
      files: response.data.FileStatuses.FileStatus
    });
  } catch (error) {
    console.error('列出目录错误:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      error: '列出目录失败',
      message: error.message,
      status: error.response?.status || 500
    });
  }
});

// 健康检查接口
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'healthy', timestamp: new Date() });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`HDFS RESTful 服务已启动,端口: ${PORT}`);
  console.log(`前端页面: http://localhost:${PORT}`);
  console.log(`HDFS NameNode: http://${HDFS_NAMENODE_HOST}:${HDFS_NAMENODE_PORT}`);
});
