const express = require("express");
require('dotenv').config();
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.text()); // 用于接收文件内容
app.use(bodyParser.urlencoded({ extended: true }));


const PORT = process.env.PORT || 8000;

// HDFS 配置 - 从环境变量或默认值获取
const HDFS_NAMENODE_HOST = process.env.HDFS_NAMENODE_HOST || 'localhost';
const HDFS_NAMENODE_PORT = process.env.HDFS_NAMENODE_PORT || 50070;
const HDFS_USER = process.env.HDFS_USER || 'hadoop';

const baseHdfsUrl = `http://${HDFS_NAMENODE_HOST}:${HDFS_NAMENODE_PORT}/webhdfs/v1/user/root`;

/**
 * 创建 HDFS 文件夹
 * POST /api/hdfs/mkdir
 * 请求体: { "path": "/user/test/newdir" }
 */
app.post('/api/hdfs/mkdir', async (req, res) => {
    try {
        const { path } = req.body;
        
        if (!path) {
            return res.status(400).json({ error: '请提供 HDFS 路径' });
        }
        
        const url = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=MKDIRS&permission=755`;
        
        const response = await axios.put(url);
        
        res.status(200).json({
            message: `文件夹创建成功: ${path}`,
            hdfsResponse: response.data
        });
    } catch (error) {
        console.error('创建文件夹错误:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({
            error: '创建文件夹失败',
            details: error.response?.data || error.message
        });
    }
});

/**
 * 创建 HDFS 文件
 * POST /api/hdfs/create
 * 请求体: 文件内容 (文本)
 * 查询参数: path (例如: /user/test/file.txt)
 */
app.post('/api/hdfs/create', async (req, res) => {
    try {
        const { path } = req.query;
        const content = req.body;
        
        if (!path) {
            return res.status(400).json({ error: '请提供 HDFS 文件路径作为查询参数' });
        }
        
        if (!content) {
            return res.status(400).json({ error: '请提供文件内容' });
        }
        
        // 第一步: 获取创建文件的重定向 URL
        const createUrl = `${baseHdfsUrl}${path}?user.name=${HDFS_USER}&op=CREATE&overwrite=true`;
        
        const createResponse = await axios.put(createUrl, null, {
            maxRedirects: 0, // 不自动重定向，以便获取位置头
            validateStatus: status => status === 307 // 只接受 307 状态码
        });
        
        // 第二步: 使用重定向 URL 写入文件内容
        const writeUrl = createResponse.headers.location;
        console.log('重定向 URL:', writeUrl);
        const writeResponse = await axios.put(writeUrl, content);
        
        res.status(200).json({
            message: `文件创建成功: ${path}`,
            hdfsResponse: writeResponse.data
        });
    } catch (error) {
        console.error('创建文件错误:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({
            error: '创建文件失败',
            details: error.response?.data || error.message
        });
    }
});

// 继续使用之前的依赖和配置...

/**
 * 删除 HDFS 文件或文件夹
 * DELETE /api/hdfs/delete
 * 查询参数: 
 *   path: 要删除的HDFS路径 (例如: /file.txt 或 /folder)
 *   recursive: 是否递归删除(删除文件夹时需要，可选值: true/false，默认false)
 */
app.delete('/api/hdfs/delete', async (req, res) => {
    try {
        const { path, recursive = false } = req.query;
        
        if (!path) {
            return res.status(400).json({ error: '请提供 HDFS 路径作为查询参数' });
        }
        
        // 构建删除请求URL
        const url = new URL(`${baseHdfsUrl}${path}`);
        url.searchParams.append('user.name', HDFS_USER);
        url.searchParams.append('op', 'DELETE');
        url.searchParams.append('recursive', recursive);
        
        const response = await axios.delete(url.toString());
        
        res.status(200).json({
            message: `成功删除: ${path}`,
            hdfsResponse: response.data
        });
    } catch (error) {
        console.error('删除错误:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({
            error: '删除失败',
            details: error.response?.data || error.message,
            path: req.query.path
        });
    }
});

// 健康检查接口
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'healthy', timestamp: new Date() });
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`HDFS RESTful 服务已启动，端口: ${PORT}`);
});
