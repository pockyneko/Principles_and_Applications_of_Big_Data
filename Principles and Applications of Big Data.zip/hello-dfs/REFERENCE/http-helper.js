// httpClient.js
const HttpClient = (function () {
  // 私有工具函数（仅内部可见）
  function getFullUrl(baseURL, url) {
    return baseURL
      ? `${baseURL.replace(/\/$/, "")}/${url.replace(/^\//, "")}`
      : url;
  }

  async function handleError(error) {
    if (error instanceof Response) {
      let errorMsg = `请求失败: ${error.status} ${error.statusText}`;
      try {
        const data = await error.json();
        errorMsg = data.message || errorMsg;
      } catch {
        // 非JSON响应不处理
      }
      return Promise.reject(new Error(errorMsg));
    }
    return Promise.reject(new Error(error.message || "网络请求失败"));
  }

  // 构造函数（通过闭包维护实例私有状态）
  function HttpClientConstructor(baseURL = "") {
    // 私有状态（实例级私有，通过闭包隔离）
    let _baseURL = baseURL;
    let _requestInterceptor = (config) => config;
    let _responseInterceptor = (response) => response;

    // 暴露的公共方法（通过闭包访问私有状态）
    this.setBaseURL = (url) => {
      _baseURL = url;
    };

    this.setRequestInterceptor = (interceptor) => {
      _requestInterceptor = interceptor;
    };

    this.setResponseInterceptor = (interceptor) => {
      _responseInterceptor = interceptor;
    };

    this.request = async function (url, options = {}) {
      try {
        const defaultOptions = {
          headers: {
            "Content-Type": "application/json",
          },
          ...options,
        };

        // 应用请求拦截器（访问私有拦截器）
        const config = _requestInterceptor({
          url,
          options: defaultOptions,
        });

        // 发送请求（使用私有URL处理函数）
        const response = await fetch(getFullUrl(_baseURL, config.url), config.options);

        if (!response.ok) {
          return handleError(response); // 调用私有错误处理
        }

        // 解析响应
        const contentType = response.headers.get("content-type");
        let data = contentType?.includes("application/json") 
          ? await response.json() 
          : await response.text();

        // 应用响应拦截器（访问私有拦截器）
        return _responseInterceptor(data);
      } catch (error) {
        return handleError(error);
      }
    };

    this.get = function (url, params = {}, options = {}) {
      const queryParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value != null) queryParams.append(key, value);
      });
      const queryString = queryParams.toString();
      const fullUrl = queryString ? `${url}?${queryString}` : url;

      return this.request(fullUrl, { method: "GET", ...options });
    };

    this.post = function (url, data = {}, options = {}) {
      return this.request(url, {
        method: "POST",
        body: JSON.stringify(data),
        ...options,
      });
    };

    this.put = function (url, data = {}, options = {}) {
      return this.request(url, {
        method: "PUT",
        body: JSON.stringify(data),
        ...options,
      });
    };

    this.delete = function (url, data = {}, options = {}) {
      return this.request(url, {
        method: "DELETE",
        body: Object.keys(data).length ? JSON.stringify(data) : undefined,
        ...options,
      });
    };

    this.upload = function (url, formData, onProgress = () => {}, options = {}) {
      return this.request(url, {
        method: "POST",
        body: formData,
        headers: {}, // 移除默认Content-Type，由浏览器自动处理
        ...options,
        onUploadProgress: onProgress,
      });
    };
  }

  // 创建默认实例（闭包内创建，外部无法修改内部状态）
  const defaultInstance = new HttpClientConstructor();

  // 暴露公共接口（仅暴露必要的类和实例）
  return {
    HttpClient: HttpClientConstructor,
    http: defaultInstance
  };
})();
