## 后端

### 加载静态网页

```js
app.use(express.static('static'));
```

## HTML 骨架

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>我的网盘</title>
  <!-- 引入 Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- 引入 Font Awesome 图标 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- 侧边栏 -->
      <div class="col-md-2">
        侧边栏
      </div>

      <!-- 文件列表区域 -->
      <main class="col-md-10">
        文件列表区域
      </main>
    </div>
  </div>
  <!-- 引入 Bootstrap JS 和 Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  </script>
</body>
</html>
```

## 顶部导航栏

### HTML

```html
  <!-- 顶部导航栏 -->
  <nav class="navbar navbar-light bg-white">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <i class="fas fa-cloud text-primary me-2"></i>我的网盘
      </a>
    </div>
  </nav>
```

### CSS

```
/* 顶部导航栏 */
.navbar {
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  z-index: 1030;
}
```


## 侧边栏

### HTML

```html
<!-- 侧边栏 -->
<div class="col-md-2 sidebar">
  <div class="d-flex flex-column h-100 py-4">
    <div class="mb-4 px-3">
      <button class="btn btn-primary w-100 mb-2" id="newFolderBtn">
        <i class="fas fa-folder-plus me-2"></i>新建文件夹
      </button>
      <button class="btn btn-secondary w-100" id="newFileBtn">
        <i class="fas fa-file-alt me-2"></i>新建文本文件
      </button>
    </div>

    <div class="mt-auto px-3">
      <div class="bg-light rounded p-3">
        <h6 class="text-uppercase text-muted small mb-2">存储空间</h6>
        <div class="progress mb-2" style="height: 6px">
          <div
            class="progress-bar bg-primary"
            role="progressbar"
            style="width: 35%"
            aria-valuenow="35"
            aria-valuemin="0"
            aria-valuemax="100"
          ></div>
        </div>
        <p class="text-xs text-muted mb-0">已使用 3.5GB / 10GB</p>
      </div>
    </div>
  </div>
  <!-- 文件列表区域 -->
  <main class="col-md-10 files-area">
    <div class="row" id="fileGrid"></div>
  </main>
</div>
```

### CSS

```css
/* 侧边栏 */
.sidebar {
  height: calc(100vh - 56px);
  background-color: #fff;
  border-right: 1px solid #e2e8f0;
  transition: all 0.3s ease;
}

.sidebar .nav-link {
  color: #64748b;
  padding: 0.75rem 1rem;
  transition: all 0.2s;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active {
  color: #2563eb;
  background-color: #eff6ff;
  border-left: 3px solid #2563eb;
}
```


### 响应式

```html
<button class="btn btn-outline-secondary me-2 d-md-none" id="sidebarToggle">
<i class="fas fa-bars"></i>
</button>
```

```css
/* 响应式调整 */
@media (max-width: 768px) {
  .sidebar {
    position: fixed;
    left: -250px;
    z-index: 1020;
    width: 250px;
  }
  
  .sidebar.show {
    left: 0;
  }

}
```

```js
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.querySelector('.sidebar');
sidebarToggle.addEventListener('click', () => {
  sidebar.classList.toggle('show');
});
```

## 列表

### 容器 HTML

```html
<!-- 文件列表区域 -->
<main class="col-md-10 files-area">
  <div class="row">
  </div>
</main>
```

### 项目 ITEM

```html
<!-- 文件夹 -->
<div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-3 file-item">
  <div class="p-3">
    <div class="file-icon  mb-2">
      <i class="fas fa-folder folder-icon"></i>
    </div>
    <div class="d-flex justify-content-between align-items-center">
      <h6 class="mb-0 text-truncate">工作文档</h6>
      <div class="action-buttons">
        <button class="btn btn-sm btn-outline-danger delete-btn">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
    <p class="text-xs text-muted mb-0">2023-06-15</p>
  </div>
</div>
```

### CSS

```css
/* 文件列表区域 */
.files-area {
padding: 1.5rem;
overflow-y: auto;
height: calc(100vh - 56px);
}

.file-item {
transition: all 0.2s ease;
cursor: pointer;
border-radius: 0.375rem;
}

.file-item:hover {
background-color: #f1f5f9;
}

.file-item.selected {
background-color: #dbeafe;
}

.file-item:hover .action-buttons {
opacity: 1;
}

.file-icon {
font-size: 2rem;
}

.folder-icon {
color: #f59e0b;
}

.file-text-icon {
color: #3b82f6;
}
```

### 生成列表

```js
async function loadFiles(path) {
  const data = await http.get(`/api/hdfs/list?path=${encodeURIComponent(path)}`);
  let html = "";
  let itemCss = "";
  for (const file of data.items) {
    if (file.type === "DIRECTORY") itemCss = "fas fa-folder folder-icon";
    else itemCss = "fas fa-file-alt file-text-icon";
    html += `
<div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-3 file-item">
  <div class="p-3">
    <div class="file-icon  mb-2">
      <i class="${itemCss}"></i>
    </div>
    <div class="d-flex justify-content-between align-items-center">
      <h6 class="mb-0 text-truncate">${file.name}</h6>
      <div class="action-buttons">
        <button class="btn btn-sm btn-outline-danger delete-btn">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
    <p class="text-xs text-muted mb-0">${file.modificationTime.substr(0, 10)}</p>
  </div>
</div>
    `;
  }
  const fileGrid = document.getElementById("fileGrid");
  fileGrid.innerHTML = html;    
}

```


## 创建文件夹

### HTML

```html
<!-- 新建文件夹模态框 -->
<div class="modal fade" id="newFolderModal" tabindex="-1" aria-labelledby="newFolderModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="newFolderModalLabel">新建文件夹</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="mb-3">
        <label for="folderName" class="form-label">文件夹名称</label>
        <input type="text" class="form-control" id="folderName" placeholder="请输入文件夹名称">
        <div class="invalid-feedback" id="folderNameError">
            请输入文件夹名称
        </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
        <button type="button" class="btn btn-primary" id="createFolderBtn">创建</button>
    </div>
    </div>
  </div>
</div>
```


### 显示对话框

```js
const newFolderBtn = document.getElementById('newFolderBtn');
const newFolderModal = new bootstrap.Modal(document.getElementById('newFolderModal'));
const folderNameInput = document.getElementById('folderName');

newFolderBtn.addEventListener('click', () => {
  folderNameInput.value = '';
  folderNameInput.classList.remove('is-invalid');
  newFolderModal.show();
});

```

### 执行创建

```js
const createFolderBtn = document.getElementById('createFolderBtn');
createFolderBtn.addEventListener('click', async () => {
  const folderName = folderNameInput.value.trim();
  if (!folderName) {
    folderNameInput.classList.add('is-invalid');
    return;
  }
  await http.post('/api/hdfs/mkdir', { path: `/${folderName}` });
  await loadFiles("/");
  newFolderModal.hide();
});
```

## 新建文件

```html
<!-- 新建文本文件模态框 -->
<div class="modal fade" id="newFileModal" tabindex="-1" aria-labelledby="newFileModalLabel" aria-hidden="true">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="newFileModalLabel">新建文本文件</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
      <div class="mb-3">
        <label for="fileName" class="form-label">文件名称</label>
        <input type="text" class="form-control" id="fileName" placeholder="请输入文件名称">
        <div class="invalid-feedback" id="fileNameError">
          请输入文件名称
        </div>
        <div class="form-text">文件名无需包含 .txt 扩展名</div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
      <button type="button" class="btn btn-primary" id="createFileBtn">创建</button>
    </div>
  </div>
</div>
</div>
```

### 模仿补充

## 删除文件或文件夹

### HTML

```HTML
<!-- 删除确认模态框 -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteConfirmModalLabel">确认删除</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        您确定要删除选中的项目吗？此操作无法撤销。
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">删除</button>
      </div>
    </div>
  </div>
</div>
```

### 显示对话框

```js
const deleteConfirmModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const fileGrid = document.getElementById('fileGrid');
let deletePath = "";

fileGrid.addEventListener('click', (e) => {
  const fileItem = e.target.closest('.file-item');
  if (fileItem && e.target.closest('.delete-btn')) {
    deletePath = fileItem.dataset.path;
    deleteConfirmModal.show();
  }
});
```

### 执行删除

```js
confirmDeleteBtn.addEventListener('click', async () => {
  await http.delete(`/api/hdfs/delete?path=${deletePath}`);
  await loadFiles("/");
  deleteConfirmModal.hide();
});

```