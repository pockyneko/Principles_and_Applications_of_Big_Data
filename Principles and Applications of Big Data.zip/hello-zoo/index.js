const express = require('express');
const zookeeper = require('node-zookeeper-client');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// 连接 ZooKeeper 集群
const zkServers = 'myzoo1:2181,myzoo2:2181,myzoo3:2181';
console.log('🎰 分布式抽奖系统启动中...');
console.log('📡 连接 ZooKeeper 集群:', zkServers);

const zkClient = zookeeper.createClient(zkServers, {
  sessionTimeout: 10000,
  spinDelay: 1000,
  retries: 3
});

zkClient.connect();

// 抽奖配置
const LOTTERY_CONFIG = {
  prizes: [
    { id: 1, name: '一等奖 - iPhone 15 Pro', probability: 0.01, stock: 1 },
    { id: 2, name: '二等奖 - iPad Air', probability: 0.05, stock: 3 },
    { id: 3, name: '三等奖 - AirPods Pro', probability: 0.10, stock: 10 },
    { id: 4, name: '四等奖 - 100元红包', probability: 0.20, stock: 50 },
    { id: 5, name: '谢谢参与', probability: 0.64, stock: 999999 }
  ]
};

// 初始化 ZooKeeper 节点
zkClient.once('connected', () => {
  console.log('✅ ZooKeeper 集群连接成功');

  // 创建根节点
  const paths = [
    '/lottery',
    '/lottery/participants',
    '/lottery/winners',
    '/lottery/config',
    '/lottery/stock'
  ];

  let completed = 0;
  paths.forEach(p => {
    zkClient.exists(p, (error, stat) => {
      if (!stat) {
        zkClient.create(p, Buffer.from(''), zookeeper.CreateMode.PERSISTENT, (err) => {
          if (err && err.getCode() !== zookeeper.Exception.NODE_EXISTS) {
            console.error(`创建节点失败 ${p}:`, err.message);
          } else {
            console.log(`✅ 初始化节点: ${p}`);
          }
          completed++;
          if (completed === paths.length) {
            initializePrizeStock();
          }
        });
      } else {
        completed++;
        if (completed === paths.length) {
          initializePrizeStock();
        }
      }
    });
  });
});

// 初始化奖品库存
function initializePrizeStock() {
  LOTTERY_CONFIG.prizes.forEach(prize => {
    const stockPath = `/lottery/stock/${prize.id}`;
    zkClient.exists(stockPath, (error, stat) => {
      if (!stat) {
        zkClient.create(
          stockPath,
          Buffer.from(prize.stock.toString()),
          zookeeper.CreateMode.PERSISTENT,
          (err) => {
            if (err && err.getCode() !== zookeeper.Exception.NODE_EXISTS) {
              console.error(`初始化库存失败 ${prize.name}:`, err.message);
            } else {
              console.log(`✅ 初始化库存: ${prize.name} - ${prize.stock}件`);
            }
          }
        );
      }
    });
  });
}

zkClient.on('disconnected', () => {
  console.log('⚠️  与 ZooKeeper 断开连接');
});

// API: 用户参与抽奖（注册在线用户）
app.post('/api/join', (req, res) => {
  const { username } = req.body;

  if (!username) {
    return res.status(400).json({ error: '用户名不能为空' });
  }

  const userPath = `/lottery/participants/${username}`;

  // 创建临时节点，用户断开连接时自动删除
  zkClient.create(
    userPath,
    Buffer.from(JSON.stringify({ joinTime: Date.now() })),
    zookeeper.CreateMode.EPHEMERAL,
    (error) => {
      if (error) {
        if (error.getCode() === zookeeper.Exception.NODE_EXISTS) {
          return res.json({ success: true, message: '欢迎回来' });
        }
        return res.status(500).json({ error: '参与失败: ' + error.message });
      }
      res.json({ success: true, message: '参与成功，祝你好运！' });
    }
  );
});

// API: 获取在线用户数
app.get('/api/online', (req, res) => {
  zkClient.getChildren('/lottery/participants', (error, children) => {
    if (error) {
      return res.status(500).json({ error: '获取失败' });
    }
    res.json({
      online: children.length,
      users: children
    });
  });
});

// API: 抽奖（使用分布式锁）
app.post('/api/draw', async (req, res) => {
  const { username } = req.body;

  if (!username) {
    return res.status(400).json({ error: '用户名不能为空' });
  }

  const lockPath = '/lottery/lock';

  // 尝试获取分布式锁
  zkClient.create(
    lockPath,
    Buffer.from(username),
    zookeeper.CreateMode.EPHEMERAL,
    async (error) => {
      if (error) {
        if (error.getCode() === zookeeper.Exception.NODE_EXISTS) {
          return res.status(423).json({ error: '有人正在抽奖，请稍后再试' });
        }
        return res.status(500).json({ error: '抽奖失败: ' + error.message });
      }

      // 获取锁成功，执行抽奖逻辑
      try {
        const result = await performLottery(username);

        // 释放锁
        zkClient.remove(lockPath, -1, (err) => {
          if (err) {
            console.error('释放锁失败:', err.message);
          }
        });

        res.json(result);
      } catch (err) {
        // 确保释放锁
        zkClient.remove(lockPath, -1, () => {});
        res.status(500).json({ error: err.message });
      }
    }
  );
});

// 执行抽奖逻辑
function performLottery(username) {
  return new Promise((resolve, reject) => {
    // 随机抽奖算法
    const rand = Math.random();
    let accumulate = 0;
    let selectedPrize = null;

    for (const prize of LOTTERY_CONFIG.prizes) {
      accumulate += prize.probability;
      if (rand <= accumulate) {
        selectedPrize = prize;
        break;
      }
    }

    if (!selectedPrize) {
      selectedPrize = LOTTERY_CONFIG.prizes[LOTTERY_CONFIG.prizes.length - 1];
    }

    // 检查并扣减库存
    const stockPath = `/lottery/stock/${selectedPrize.id}`;

    zkClient.getData(stockPath, (error, data, stat) => {
      if (error) {
        return reject(new Error('获取库存失败'));
      }

      let stock = parseInt(data.toString());

      if (stock <= 0 && selectedPrize.id !== 5) {
        // 库存不足，给谢谢参与
        selectedPrize = LOTTERY_CONFIG.prizes.find(p => p.id === 5);
      }

      // 扣减库存
      if (selectedPrize.id !== 5) {
        stock--;
        zkClient.setData(stockPath, Buffer.from(stock.toString()), stat.version, (err) => {
          if (err) {
            console.error('更新库存失败:', err.message);
          }
        });
      }

      // 保存中奖记录
      const winnerData = {
        username,
        prize: selectedPrize.name,
        prizeId: selectedPrize.id,
        time: new Date().toLocaleString('zh-CN'),
        timestamp: Date.now()
      };

      const winnerPath = `/lottery/winners/${Date.now()}_${username}`;

      zkClient.create(
        winnerPath,
        Buffer.from(JSON.stringify(winnerData)),
        zookeeper.CreateMode.PERSISTENT,
        (err) => {
          if (err) {
            console.error('保存中奖记录失败:', err.message);
          }

          resolve({
            success: true,
            prize: selectedPrize,
            message: selectedPrize.id === 5 ? '很遗憾，再接再厉！' : '恭喜中奖！',
            remainingStock: stock
          });
        }
      );
    });
  });
}

// API: 获取中奖记录
app.get('/api/winners', (req, res) => {
  zkClient.getChildren('/lottery/winners', (error, children) => {
    if (error) {
      return res.status(500).json({ error: '获取失败' });
    }

    if (children.length === 0) {
      return res.json([]);
    }

    // 获取最近20条记录
    const recentWinners = children.sort().reverse().slice(0, 20);
    let completed = 0;
    const winners = [];

    recentWinners.forEach(child => {
      const childPath = `/lottery/winners/${child}`;
      zkClient.getData(childPath, (err, data) => {
        if (!err && data) {
          try {
            winners.push(JSON.parse(data.toString()));
          } catch (e) {
            console.error('解析中奖记录失败:', e.message);
          }
        }
        completed++;
        if (completed === recentWinners.length) {
          // 按时间戳倒序排序
          winners.sort((a, b) => b.timestamp - a.timestamp);
          res.json(winners);
        }
      });
    });
  });
});

// API: 获取奖品库存
app.get('/api/stock', (req, res) => {
  const prizes = [...LOTTERY_CONFIG.prizes];
  let completed = 0;

  prizes.forEach(prize => {
    const stockPath = `/lottery/stock/${prize.id}`;
    zkClient.getData(stockPath, (error, data) => {
      if (!error && data) {
        prize.currentStock = parseInt(data.toString());
      } else {
        prize.currentStock = prize.stock;
      }
      completed++;
      if (completed === prizes.length) {
        res.json(prizes);
      }
    });
  });
});

// API: 健康检查
app.get('/api/health', (req, res) => {
  const state = zkClient.getState();
  res.json({
    status: state.name,
    connected: state.name === 'SYNC_CONNECTED',
    servers: zkServers
  });
});

// 提供主页
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🎰 分布式抽奖系统启动成功！`);
  console.log(`📡 端口: ${PORT}`);
  console.log(`🌐 访问地址: http://localhost:${PORT}`);
  console.log(`🔗 ZooKeeper 集群: ${zkServers}\n`);
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('\n正在关闭服务...');
  zkClient.close();
  process.exit(0);
});

