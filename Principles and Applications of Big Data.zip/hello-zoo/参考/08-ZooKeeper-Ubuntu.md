## 配置环境 

### 创建容器

```sh
docker run -itd `
--name myzoo `
--privileged `
-p 2181:2181 `
myubuntu run.sh
```

### 复制 zookeeper
```sh
docker cp apache-zookeeper-3.8.0-bin.tar.gz myzoo:/root/
```

### 进入容器
```sh
docker exec -it myzoo bash
```

### 解压缩
```sh
cd ~
tar -xzvf apache-zookeeper-3.8.0-bin.tar.gz
mv apache-zookeeper-3.8.0-bin zookeeper
rm -f apache-zookeeper-3.8.0-bin.tar.gz
```


### 环境变量

编辑 .bash_aliases
```sh
vi .bash_aliases
```
添加 
```sh
# ZOOKEEPER
export ZOOKEEPER=/root/zookeeper
export PATH=$ZOOKEEPER/bin:${PATH}
```
生效 .bashrc
```sh
source .bash_aliases
```

## 单机版本

### vi ~/zookeeper/conf/zoo.cfg

```
tickTime=2000
dataDir=/var/lib/zookeeper
clientPort=2181
```


### 启动查看状态

```
zkServer.sh start
zkServer.sh status
zkServer.sh stop
```

### 测试命名

启动 client shell

```
zkCli.sh
zkCli.sh -server 127.0.0.1:2181
```

命令

```
ls /
create /root my_data
get /root
set /root other_data
delete /root
```

### 创建容器

```sh
docker commit myzoo myzoo
```

## 集群模式

PowerShell

```batch
@echo off
setlocal enabledelayedexpansion
set IP_PREFIX=172.18.11
set /a HOST_COUNT=3
set /a SUB_HOST_COUNT=%HOST_COUNT% - 1
for /l %%i in (1,1, %HOST_COUNT%) do (
	set add_host=
	for /l %%j in (1,1, %SUB_HOST_COUNT%) do (
		set /a K=%%i+%%j-1
		set /a K=!k!%%%HOST_COUNT%+1
		set add_host=!add_host! --add-host=myzoo!k!:%IP_PREFIX%.!k!
	)
	docker run -itd ^
      --network=mynet ^
      --name=myzoo%%i ^
      --hostname=myzoo%%i ^
      --ip=%IP_PREFIX%.%%i ^
      -p 218!k!:2181 ^
      !add_host! ^
      --privileged ^
      myzoo run.sh
)
@echo on
```



## 停止、删除容器名 my 开始的容器
```
docker stop $(docker ps -aq --filter="name=myzoo*")
docker rm $(docker ps -aq --filter="name=myzoo*")
```

## zoo_cluster.cfg

注意必须是 \n 换行

```
tickTime=2000
dataDir=/var/lib/zookeeper
clientPort=2181
initLimit=5
syncLimit=2
server.1=myzoo1:2888:3888
server.2=myzoo2:2888:3888
server.3=myzoo3:2888:3888
```

## 配置 server.properties

```sh
docker cp zoo_cluster.cfg myzoo1:/root/zookeeper/conf/zoo.cfg
docker cp zoo_cluster.cfg myzoo2:/root/zookeeper/conf/zoo.cfg
docker cp zoo_cluster.cfg myzoo3:/root/zookeeper/conf/zoo.cfg
```


```sh
ssh myzoo1
echo 1 > /var/lib/zookeeper/myid
ssh myzoo2
echo 2 > /var/lib/zookeeper/myid
ssh myzoo3
echo 3 > /var/lib/zookeeper/myid
```



